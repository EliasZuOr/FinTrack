<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PolicyController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\AuxiliaryController;
use App\Http\Controllers\ImportController;

Route::get('/', function () {
    return redirect()->route('dashboard');
    
});
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');



Route::get('/polizas', [PolicyController::class, 'index'])->name('polizas.index');
Route::post('/polizas', [PolicyController::class, 'store'])->name('polizas.store');
Route::delete('/polizas/{policy}', [PolicyController::class, 'destroy'])->name('polizas.destroy');
Route::put('/polizas/{policy}', [PolicyController::class, 'update'])->name('polizas.update');



Route::get('/catalogo', [AccountController::class, 'index'])->name('cuentas.index');
Route::post('/catalogo', [AccountController::class, 'store'])->name('cuentas.store');
Route::delete('/catalogo/{account}', [AccountController::class, 'destroy'])->name('cuentas.destroy');
Route::put('/catalogo/{account}', [AccountController::class, 'update'])->name('cuentas.update');

Route::get('/auxiliares', [AuxiliaryController::class, 'index'])->name('auxiliares.index');



Route::get('/importacion', [ImportController::class, 'index'])->name('importacion.index');
Route::post('/importacion', [ImportController::class, 'store'])->name('importacion.store');
Route::delete('/importacion/{fileUpload}', [ImportController::class, 'destroy'])->name('importacion.destroy');