@extends('layouts.app')

@section('title', 'Catálogo de Cuentas - FinTrack')

@section('content')

<div x-data="{ 
    isCreateModalOpen: false, 
    isDeleteModalOpen: false, 
    isEditModalOpen: false, 
    accountToDelete: null, 
    accountToEdit: {} 
}">

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Catálogo de Cuentas</h1>
        <button @click="isCreateModalOpen = true" class="bg-green-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-green-700 transition">
            + Nueva Cuenta
        </button>
    </div>

    @if (session('success'))
        <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative" role="alert">
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif
    @if (session('error'))
        <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative" role="alert">
            <span class="block sm:inline">{{ session('error') }}</span>
        </div>
    @endif


    <div class="bg-white p-6 rounded-xl shadow-md">
        <div class="mb-4">
            <input type="text" placeholder="Buscar por código o nombre de cuenta..." 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="border border-gray-200 rounded-lg">
            <div class="grid grid-cols-12 gap-4 p-4 border-b bg-gray-50 font-semibold text-gray-600 text-sm">
                <div class="col-span-2">Código</div>
                <div class="col-span-5">Nombre de la Cuenta</div>
                <div class="col-span-2">Naturaleza</div>
                <div class="col-span-2">Total de Cuenta</div>
                <div class="col-span-1"></div>
            </div>

            @forelse ($accounts as $account)
            <div class="grid grid-cols-12 gap-4 p-4 border-b items-center hover:bg-gray-50">
                
                <div class="col-span-2 font-medium text-gray-800">{{ $account->code }}</div>
                
                <div class="col-span-5 text-gray-700">{{ $account->name }}</div>
                
                <div class="col-span-2">
                    <span class="text-xs font-medium px-2 py-0.5 rounded-full 
                        {{ $account->nature == 'Deudora' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700' }}">
                        {{ $account->nature }}
                    </span>
                </div>
                
                <div class="col-span-2 font-semibold text-gray-900">
                    ${{ number_format($account->balance, 2) }}
                </div>

                <div class="col-span-1 flex justify-end space-x-2">
                    <button @click="accountToEdit = {{ $account }}; isEditModalOpen = true"
                            class="text-gray-500 hover:text-blue-600" 
                            title="Editar">
                        ✏️
                    </button>
                    
                    <button @click="accountToDelete = {{ $account }}; isDeleteModalOpen = true" 
                            class="text-gray-500 hover:text-red-600" 
                            title="Eliminar">
                        🗑️
                    </button>
                </div>

            </div> @empty
            <div class="p-4 text-center text-gray-500">
                No hay cuentas registradas. ¡Crea la primera!
            </div>
        @endforelse
        </div>
    </div>


    <div 
        x-show="isCreateModalOpen" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50"
        style="display: none;" 
    >
        <div 
            @click.away="isCreateModalOpen = false" 
            x-show="isCreateModalOpen"
            class="bg-white rounded-xl shadow-2xl w-full max-w-md"
        >
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-2xl font-semibold text-gray-800">Crear Nueva Cuenta</h2>
            </div>
            <form action="{{ route('cuentas.store') }}" method="POST">
                @csrf
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="space-y-4">
                            <div>
                                <label for="code" class="block text-sm font-medium text-gray-700">Código de Cuenta</label>
                                <input type="text" name="code" id="code" value="{{ old('code') }}" placeholder="Ej. 1000" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 @error('code') border-red-500 @enderror">
                                @error('code')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                            </div>
                            <div>
                                <label for="nature" class="block text-sm font-medium text-gray-700">Naturaleza</label>
                                <select name="nature" id="nature" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 @error('nature') border-red-500 @enderror">
                                    <option value="" disabled selected>Selecciona una naturaleza</option>
                                    <option value="Deudora" @if(old('nature') == 'Deudora') selected @endif>Deudora</option>
                                    <option value="Acreedora" @if(old('nature') == 'Acreedora') selected @endif>Acreedora</option>
                                </select>
                                @error('nature')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                            </div>
                            <div>
                                <label for="parent_id" class="block text-sm font-medium text-gray-700">Cuenta Padre (Opcional)</label>
                                <select name="parent_id" id="parent_id" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 @error('parent_id') border-red-500 @enderror">
                                    <option value="">-- Ninguna (Cuenta principal) --</option>
                                    @foreach ($accounts as $account)
                                        <option value="{{ $account->id }}" @if(old('parent_id') == $account->id) selected @endif>
                                            {{ $account->code }} - {{ $account->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('parent_id')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                            </div>
                        </div>
                        <div class="space-y-4">
                            <div>
                                <label for="name" class="block text-sm font-medium text-gray-700">Nombre de la Cuenta</label>
                                <input type="text" name="name" id="name" value="{{ old('name') }}" placeholder="Ej. ACTIVO" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 @error('name') border-red-500 @enderror">
                                @error('name')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                            </div>
                            <div>
                                <label for="sat_code" class="block text-sm font-medium text-gray-700">Código Agrupador SAT (Opcional)</label>
                                <input type="text" name="sat_code" id="sat_code" value="{{ old('sat_code') }}" placeholder="Ej. 101.01" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 @error('sat_code') border-red-500 @enderror">
                                @error('sat_code')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                            </div>
                        </div>
                </div>
                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isCreateModalOpen = false" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">Cancelar</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-blue-700">Guardar Cuenta</button>
                </div>
            </form>
        </div>
    </div>
    <div 
        x-show="isEditModalOpen" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50"
        style="display: none;"
    >
        <div 
            @click.away="isEditModalOpen = false" 
            x-show="isEditModalOpen"
            class="bg-white rounded-xl shadow-2xl w-full max-w-md"
        >
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-2xl font-semibold text-gray-800">Editar Cuenta</h2>
            </div>

            <form :action="'/catalogo/' + (accountToEdit ? accountToEdit.id : '')" method="POST">
                @csrf
                @method('PUT')
                
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="space-y-4">
                        <div>
                            <label for="edit_code" class="block text-sm font-medium text-gray-700">Código de Cuenta</label>
                            <input type="text" name="code" id="edit_code" :value="accountToEdit.code" 
                                   class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        <div>
                            <label for="edit_nature" class="block text-sm font-medium text-gray-700">Naturaleza</label>
                            <select name="nature" id="edit_nature" :value="accountToEdit.nature" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="Deudora">Deudora</option>
                                <option value="Acreedora">Acreedora</option>
                            </select>
                        </div>
                        <div>
                            <label for="edit_parent_id" class="block text-sm font-medium text-gray-700">Cuenta Padre (Opcional)</label>
                            <select name="parent_id" id="edit_parent_id" :value="accountToEdit.parent_id" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="">-- Ninguna (Cuenta principal) --</option>
                                @foreach ($accounts as $account)
                                    <option value="{{ $account->id }}" :selected="accountToEdit.parent_id == {{ $account->id }}">
                                        {{ $account->code }} - {{ $account->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="space-y-4">
                        <div>
                            <label for="edit_name" class="block text-sm font-medium text-gray-700">Nombre de la Cuenta</label>
                            <input type="text" name="name" id="edit_name" :value="accountToEdit.name"
                                   class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        <div>
                            <label for="edit_sat_code" class="block text-sm font-medium text-gray-700">Código Agrupador SAT (Opcional)</label>
                            <input type="text" name="sat_code" id="edit_sat_code" :value="accountToEdit.sat_code"
                                   class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                    </div>
                </div>

                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isEditModalOpen = false; accountToEdit = {}" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">
                        Cancelar
                    </button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-blue-700">
                        Guardar Cambios
                    </button>
                </div>
            </form>
        </div>
    </div>
    <div 
        x-show="isDeleteModalOpen" 
        class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50"
        style="display: none;"
    >
        <div 
            @click.away="isDeleteModalOpen = false" 
            x-show="isDeleteModalOpen"
            class="bg-white rounded-xl shadow-2xl w-full max-w-md"
        >
            <form :action="'/catalogo/' + (accountToDelete ? accountToDelete.id : '')" method="POST">
                @csrf
                @method('DELETE')
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-2xl font-semibold text-gray-800">Confirmar Eliminación</h2>
                </div>
                <div class="p-6">
                    <p class="text-gray-600">¿Estás seguro de que deseas eliminar la cuenta?</p>
                    <div class="mt-2 bg-gray-100 p-3 rounded-lg">
                        <span class="font-bold text-gray-800" x-text="accountToDelete ? accountToDelete.code : ''"></span>
                        <p class="text-sm text-gray-700" x-text="accountToDelete ? accountToDelete.name : ''"></p>
                    </div>
                    <p class="text-sm text-red-600 mt-4">Esta acción no se puede deshacer.</p>
                </div>
                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isDeleteModalOpen = false; accountToDelete = null" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">
                        Cancelar
                    </button>
                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-red-700">
                        Eliminar Cuenta
                    </button>
                </div>
            </form>
        </div>
    </div>
    </div> @endsection