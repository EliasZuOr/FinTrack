@extends('layouts.app')

@section('title', 'Dashboard - FinTrack')

@section('content')
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Dashboard</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Total Activos (Saldo)</h5>
            <p class="text-3xl font-bold text-gray-800">${{ number_format($stats['saldo_total'], 2) }}</p>

            @if($stats['saldo_percent']->is_new)
                <span class="text-xs font-medium bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Nuevo</span>
            @elseif($stats['saldo_percent']->value != 0)
                <p @class([
                    'text-xs',
                    'text-green-500' => $stats['saldo_percent']->value > 0,
                    'text-red-500' => $stats['saldo_percent']->value < 0,
                ])>
                    {{ $stats['saldo_percent']->value > 0 ? '+' : '' }}{{ $stats['saldo_percent']->value }}% vs mes anterior
                </p>
            @endif
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Ingresos (Mes)</h5>
            <p class="text-3xl font-bold text-green-600">${{ number_format($stats['ingresos_mes'], 2) }}</p>
            
            @if($stats['ingresos_percent']->is_new)
                <span class="text-xs font-medium bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Nuevo</span>
            @elseif($stats['ingresos_percent']->value != 0)
                <p @class([
                    'text-xs',
                    'text-green-500' => $stats['ingresos_percent']->value > 0,
                    'text-red-500' => $stats['ingresos_percent']->value < 0,
                ])>
                    {{ $stats['ingresos_percent']->value > 0 ? '+' : '' }}{{ $stats['ingresos_percent']->value }}% vs mes anterior
                </p>
            @endif
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Egresos (Mes)</h5>
            <p class="text-3xl font-bold text-red-600">${{ number_format($stats['egresos_mes'], 2) }}</p>
            
            @if($stats['egresos_percent']->is_new)
                <span class="text-xs font-medium bg-red-100 text-red-700 px-2 py-0.5 rounded-full">Nuevo</span>
            @elseif($stats['egresos_percent']->value != 0)
                <p @class([
                    'text-xs',
                    'text-red-500' => $stats['egresos_percent']->value > 0,
                    'text-green-500' => $stats['egresos_percent']->value < 0,
                ])>
                    {{ $stats['egresos_percent']->value > 0 ? '+' : '' }}{{ $stats['egresos_percent']->value }}% vs mes anterior
                </p>
            @endif
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Pólizas (Mes)</h5>
            <p class="text-3xl font-bold text-gray-800">{{ $stats['polizas_mes'] }}</p>
            
            @if($stats['polizas_percent']->is_new)
                <span class="text-xs font-medium bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Nuevo</span>
            @elseif($stats['polizas_percent']->value != 0)
                <p @class([
                    'text-xs',
                    'text-green-500' => $stats['polizas_percent']->value > 0,
                    'text-red-500' => $stats['polizas_percent']->value < 0,
                ])>
                    {{ $stats['polizas_percent']->value > 0 ? '+' : '' }}{{ $stats['polizas_percent']->value }}% vs mes anterior
                </p>
            @endif
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Ingreso vs Egreso (Últimos 6 meses)</h5>
            <canvas id="ingresoEgresoChart"></canvas>
        </div>
        <div class="lg:col-span-1 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Evolución de Activos (Últimos 6 meses)</h5>
            <canvas id="evolucionSaldoChart"></canvas>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-1 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Distribución de Activos (Top 4)</h5>
            <canvas id="activosChart" class="max-h-64 mx-auto"></canvas>
        </div>
        <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Accesos Rápidos</h5>
            <div class="grid grid-cols-2 gap-4">
                <a href="{{ route('polizas.index') }}" class="flex items-center p-4 bg-blue-100 text-blue-700 rounded-lg font-medium hover:bg-blue-200">
                    <i class="mr-3 text-xl">📝</i> Nueva Póliza
                </a>
                <a href="{{ route('cuentas.index') }}" class="flex items-center p-4 bg-green-100 text-green-700 rounded-lg font-medium hover:bg-green-200">
                    <i class="mr-3 text-xl">📚</i> Catálogo
                </a>
                <a href="{{ route('auxiliares.index') }}" class="flex items-center p-4 bg-purple-100 text-purple-700 rounded-lg font-medium hover:bg-purple-200">
                    <i class="mr-3 text-xl">📉</i> Ver Auxiliares
                </a>
                <a href="{{ route('importacion.index') }}" class="flex items-center p-4 bg-yellow-100 text-yellow-700 rounded-lg font-medium hover:bg-yellow-200">
                    <i class="mr-3 text-xl">📤</i> Importar CFDI
                </a>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const ctxIngresoEgreso = document.getElementById('ingresoEgresoChart').getContext('2d');
            new Chart(ctxIngresoEgreso, {
                type: 'bar',
                data: {
                    labels: @json($ingresoEgresoData['labels']),
                    datasets: [
                        {
                            label: 'Ingresos',
                            data: @json($ingresoEgresoData['ingresos']),
                            backgroundColor: 'rgba(34, 197, 94, 0.7)', 
                            borderRadius: 4,
                        },
                        {
                            label: 'Egresos',
                            data: @json($ingresoEgresoData['egresos']),
                            backgroundColor: 'rgba(239, 68, 68, 0.7)', 
                            borderRadius: 4,
                        }
                    ]
                },
                options: { 
                    responsive: true, 
                    scales: { y: { beginAtZero: true } },
                    plugins: { legend: { position: 'top' } }
                }
            });
            const ctxEvolucionSaldo = document.getElementById('evolucionSaldoChart').getContext('2d');
            new Chart(ctxEvolucionSaldo, {
                type: 'line',
                data: {
                    labels: @json($evolucionActivosData['labels']),
                    datasets: [{
                        label: 'Total Activos', 
                        data: @json($evolucionActivosData['saldo']),
                        borderColor: 'rgba(59, 130, 246, 1)', 
                        fill: false,
                        tension: 0.1
                    }]
                },
                options: { 
                    responsive: true, 
                    scales: { y: { beginAtZero: true } },
                    plugins: { legend: { position: 'top' } }
                }
            });

            const ctxActivos = document.getElementById('activosChart').getContext('2d');
            new Chart(ctxActivos, {
                type: 'doughnut',
                data: {
                    labels: @json($activosData['labels']),
                    datasets: [{
                        data: @json($activosData['data']),
                        backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6']
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        });
    </script>
@endpush