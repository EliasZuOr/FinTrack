@extends('layouts.app')

@section('title', 'Importación de Archivos - FinTrack')

@section('content')

<div x-data="{ isDeleteModalOpen: false, fileToDelete: null }">

    <h1 class="text-3xl font-bold text-gray-800 mb-6">Importación de Archivos</h1>

    @if (session('success'))
        <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative" role="alert">
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif
    @if (session('error'))
        <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative" role="alert">
            <span class="block sm:inline">{{ session('error') }}</span>
        </div>
    @endif
    @error('cfdi_file')
        <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative" role="alert">
            <span class="block sm:inline">{{ $message }}</span>
        </div>
    @enderror

    <div class="bg-white p-6 rounded-xl shadow-md mb-8"
         x-data="{ isUploading: false, fileName: '' }" 
         x-on:submit="isUploading = true">
        
        <h3 class="text-xl font-semibold text-gray-800 mb-4">Cargar Archivo CFDI</h3>
        
        <form action="{{ route('importacion.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div 
                class="relative flex flex-col items-center justify-center w-full p-12 border-2 border-gray-300 border-dashed rounded-lg"
                @dragover.prevent @dragenter.prevent
            >
                <svg class="mx-auto h-12 w-12 text-blue-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                    <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                
                <p class="mt-2 text-gray-600">
                    Arrastra tus archivos <span class="font-semibold text-blue-600">XML</span> aquí o
                </p>
                
                <label for="cfdi_file" class="mt-4 cursor-pointer bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-blue-700 transition">
                    Seleccionar Archivo
                </label>
                
                <input id="cfdi_file" name="cfdi_file" type="file" class="hidden"
                       @change="fileName = $event.target.files[0].name">
                
                <p x-show="fileName" class="mt-3 text-sm text-gray-500" x-text="'Archivo seleccionado: ' + fileName"></p>
            </div>

            <div x-show="fileName" class="flex justify-end mt-4">
                <button type="submit" 
                        :disabled="isUploading"
                        class="flex items-center justify-center bg-green-600 text-white px-6 py-2 rounded-lg font-semibold shadow hover:bg-green-700 transition"
                        :class="{ 'opacity-50 cursor-not-allowed': isUploading }">
                    <span x-show="!isUploading">Subir Archivo</span>
                    <span x-show="isUploading">Subiendo...</span>
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white p-6 rounded-xl shadow-md">
        <h3 class="text-xl font-semibold text-gray-800 mb-4">Historial de importaciones</h3>
        <div class="border border-gray-200 rounded-lg overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Archivo</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                        <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Monto</th>
                        <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse ($uploads as $upload)
                        <tr>
                            <td class="px-4 py-3 text-sm font-medium text-gray-900">{{ $upload->file_name }}</td>
                            <td class="px-4 py-3 text-sm text-gray-700">{{ $upload->created_at->format('d/m/Y H:i') }}</td>
                            <td class="px-4 py-3 text-sm text-gray-700">{{ $upload->type }}</td>
                            <td class="px-4 py-3 text-sm">
                                <span class="text-xs font-medium px-2 py-0.5 rounded-full 
                                    {{ $upload->status == 'Pendiente' ? 'bg-yellow-100 text-yellow-800' : '' }}
                                    {{ $upload->status == 'Procesado' ? 'bg-green-100 text-green-800' : '' }}
                                    {{ $upload->status == 'Error' ? 'bg-red-100 text-red-800' : '' }}
                                ">
                                    {{ $upload->status }}
                                </span>
                            </td>
                            <td class="px-4 py-3 text-sm text-right font-medium text-gray-900">
                                {{ $upload->amount ? '$' . number_format($upload->amount, 2) : 'N/A' }}
                            </td>
                            
                            <td class="px-4 py-3 text-sm text-right space-x-2">
                                <a href="{{ Storage::url($upload->storage_path) }}" target="_blank" class="text-blue-600 hover:text-blue-900" title="Ver archivo">Ver</a>
                                
                                <button @click="fileToDelete = {{ $upload }}; isDeleteModalOpen = true"
                                        class="text-red-600 hover:text-red-900" 
                                        title="Eliminar">
                                    Eliminar
                                </button>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="p-4 text-center text-gray-500">
                                No hay archivos importados todavía.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div 
        x-show="isDeleteModalOpen" 
        class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50"
        style="display: none;"
    >
        <div 
            @click.away="isDeleteModalOpen = false" 
            x-show="isDeleteModalOpen"
            class="bg-white rounded-xl shadow-2xl w-full max-w-md"
        >
            <form :action="`{{ route('importacion.index') }}/${fileToDelete ? fileToDelete.id : ''}`" method="POST">
                @csrf
                @method('DELETE')
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-2xl font-semibold text-gray-800">Confirmar Eliminación</h2>
                </div>
                <div class="p-6">
                    <p class="text-gray-600">¿Estás seguro de que deseas eliminar este archivo?</p>
                    <div class="mt-2 bg-gray-100 p-3 rounded-lg">
                        <p class="font-bold text-gray-800" x-text="fileToDelete ? fileToDelete.file_name : ''"></p>
                    </div>
                    <p class="text-sm text-red-600 mt-4">Esta acción no se puede deshacer. El archivo se borrará del servidor permanentemente.</p>
                </div>
                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isDeleteModalOpen = false; fileToDelete = null" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">
                        Cancelar
                    </button>
                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-red-700">
                        Eliminar Archivo
                    </button>
                </div>
            </form>
        </div>
    </div>
    
</div> @endsection