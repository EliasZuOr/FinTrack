@extends('layouts.app')

@section('title', 'Movimientos Auxiliares - FinTrack')

@section('content')
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Movimientos Auxiliares</h1>

    <div class="bg-white p-6 rounded-xl shadow-md mb-8">
        <form action="{{ route('auxiliares.index') }}" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            
            <div class="col-span-1 md:col-span-2">
                <label for="account_id" class="block text-sm font-medium text-gray-700">Cuenta a Consultar</label>
                <select name="account_id" id="account_id" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    <option value="">Selecciona una cuenta...</option>
                    @foreach ($accounts as $account)
                        <option value="{{ $account->id }}" @if(isset($filters['account_id']) && $filters['account_id'] == $account->id) selected @endif>
                            {{ $account->code }} - {{ $account->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            
            <div>
                <label for="start_date" class="block text-sm font-medium text-gray-700">Fecha Inicio</label>
                <input type="date" name="start_date" id="start_date" 
                       value="{{ $filters['start_date'] ?? \Carbon\Carbon::now()->startOfYear()->toDateString() }}" 
                       class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
            </div>
            
            <div>
                <label for="end_date" class="block text-sm font-medium text-gray-700">Fecha Fin</label>
                <input type="date" name="end_date" id="end_date" 
                       value="{{ $filters['end_date'] ?? \Carbon\Carbon::now()->toDateString() }}" 
                       class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
            </div>
            
            <div class="col-span-1 md:col-span-4 flex justify-end">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold shadow hover:bg-blue-700 transition">
                    Consultar
                </button>
            </div>
        </form>
    </div>

    @if ($selectedAccount)
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Saldo Inicial</h5>
                <p class="text-2xl font-bold text-gray-800">${{ number_format($summary['start_balance'], 2) }}</p>
            </div>
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Total Cargos (Debe)</h5>
                <p class="text-2xl font-bold text-green-600">${{ number_format($summary['total_debit'], 2) }}</p>
            </div>
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Total Abonos (Haber)</h5>
                <p class="text-2xl font-bold text-red-600">${{ number_format($summary['total_credit'], 2) }}</p>
            </div>
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Saldo Final</h5>
                <p class="text-2xl font-bold text-gray-800">${{ number_format($summary['end_balance'], 2) }}</p>
            </div>
        </div>

        <div class="bg-white p-6 rounded-xl shadow-md">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">
                Desglose de: {{ $selectedAccount->code }} - {{ $selectedAccount->name }} (y sub-cuentas)
            </h3>
            <div class="border border-gray-200 rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Póliza</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Concepto</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cuenta</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Cargo</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Abono</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Saldo</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <tr class="bg-gray-50">
                            <td class="px-4 py-3 text-sm font-medium text-gray-900" colspan="6">Saldo Inicial al {{ \Carbon\Carbon::parse($filters['start_date'] ?? '')->format('d/m/Y') }}</td>
                            <td class="px-4 py-3 text-right text-sm font-medium text-gray-900">${{ number_format($summary['start_balance'], 2) }}</td>
                        </tr>
                        
                        @forelse ($entries as $entry)
                            <tr>
                                <td class="px-4 py-3 text-sm text-gray-700">{{ $entry->policy->date->format('d/m/Y') }}</td>
                                <td class="px-4 py-3 text-sm text-blue-600">PL-{{ $entry->policy->id }}</td>
                                <td class="px-4 py-3 text-sm text-gray-700">{{ $entry->policy->concept }}</td>
                                <td class="px-4 py-3 text-sm text-gray-700">
                                    {{ $entry->account->code }} - {{ $entry->account->name }}
                                </td>
                                <td class="px-4 py-3 text-sm text-right text-green-600">
                                    {{ $entry->debit > 0 ? '$'.number_format($entry->debit, 2) : '-' }}
                                </td>
                                <td class="px-4 py-3 text-sm text-right text-red-600">
                                    {{ $entry->credit > 0 ? '$'.number_format($entry->credit, 2) : '-' }}
                                </td>
                                <td class="px-4 py-3 text-sm text-right font-medium text-gray-900">
                                    ${{ number_format($entry->running_balance, 2) }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="p-4 text-center text-gray-500">
                                    No se encontraron movimientos para esta ramificación de cuentas en el periodo.
                                </td>
                            </tr>
                        @endforelse

                        <tr class="bg-gray-50">
                            <td class="px-4 py-3 text-sm font-medium text-gray-900" colspan="6">Saldo Final al {{ \Carbon\Carbon::parse($filters['end_date'] ?? '')->format('d/m/Y') }}</td>
                            <td class="px-4 py-3 text-right text-sm font-bold text-gray-900">${{ number_format($summary['end_balance'], 2) }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    @else
        <div class="bg-white p-6 rounded-xl shadow-md text-center text-gray-500">
            <p>Por favor, selecciona una cuenta y un rango de fechas para ver sus movimientos auxiliares.</p>
        </div>
    @endif

@endsection