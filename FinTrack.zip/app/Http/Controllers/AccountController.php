<?php

namespace App\Http\Controllers;

use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class AccountController extends Controller
{
    public function index(): View
{
    $accounts = Account::with('policyEntries')->orderBy('code')->get();
    foreach ($accounts as $account) {
        $totalDebit = $account->policyEntries->sum('debit');
        $totalCredit = $account->policyEntries->sum('credit');

        if ($account->nature == 'Deudora') {
            $account->balance = $totalDebit - $totalCredit;
        } else { 
            $account->balance = $totalCredit - $totalDebit;
        }
    }
    return view('cuentas.index', [
        'accounts' => $accounts
    ]);
}
    public function store(Request $request): RedirectResponse
    {
        $validatedData = $request->validate([
            'code' => 'required|string|max:255|unique:accounts', 
            'name' => 'required|string|max:255',
            'nature' => 'required|string|max:255',
            'sat_code' => 'nullable|string|max:255',
            'parent_id' => 'nullable|integer|exists:accounts,id', 
        ]);
        Account::create($validatedData);
        return redirect()->route('cuentas.index')
                         ->with('success', '¡Cuenta creada exitosamente!');
    }
    public function destroy(Account $account): RedirectResponse
    {
        try {
            // if ($account->children()->count() > 0) {
            //     return redirect()->route('cuentas.index')
            //                      ->with('error', 'No se puede eliminar una cuenta que tiene sub-cuentas.');
            // }
            // if ($account->policyEntries()->count() > 0) {
            //     return redirect()->route('cuentas.index')
            //                      ->with('error', 'No se puede eliminar una cuenta con movimientos registrados.');
            // }
            $account->delete();
            return redirect()->route('cuentas.index')
                             ->with('success', '¡Cuenta eliminada exitosamente!');
        } catch (\Exception $e) {
            return redirect()->route('cuentas.index')
                             ->with('error', 'No se pudo eliminar la cuenta. Es posible que esté en uso.');
        }
    }
    public function update(Request $request, Account $account): RedirectResponse
    {
        $validatedData = $request->validate([
            'code' => 'required|string|max:255|unique:accounts,code,' . $account->id,
            'name' => 'required|string|max:255',
            'nature' => 'required|string|max:255',
            'sat_code' => 'nullable|string|max:255',
            'parent_id' => 'nullable|integer|exists:accounts,id',
        ]);
        $account->update($validatedData);
        return redirect()->route('cuentas.index')
                         ->with('success', '¡Cuenta actualizada exitosamente!');
    }
}