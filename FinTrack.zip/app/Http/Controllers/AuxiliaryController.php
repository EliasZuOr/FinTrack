<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\PolicyEntry;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Carbon\Carbon;

class AuxiliaryController extends Controller
{
    public function index(Request $request): View
    {
        $accounts = Account::orderBy('code')->get();
        $selectedAccount = null;
        $entries = [];
        $summary = [
            'start_balance' => 0,
            'total_debit' => 0,
            'total_credit' => 0,
            'end_balance' => 0,
        ];
        $request->validate([
            'account_id' => 'nullable|integer|exists:accounts,id',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);
        $accountId = $request->input('account_id');
        if ($accountId) {
            $selectedAccount = Account::find($accountId);
            $startDate = $request->input('start_date', Carbon::now()->startOfYear()->toDateString());
            $endDate = $request->input('end_date', Carbon::now()->toDateString());
            $childAccountIds = Account::where('code', 'LIKE', $selectedAccount->code . '%')
                                    ->pluck('id');
            $pastEntries = PolicyEntry::whereIn('account_id', $childAccountIds)
                ->join('policies', 'policy_entries.policy_id', '=', 'policies.id')
                ->where('policies.date', '<', $startDate)
                ->select('policy_entries.debit', 'policy_entries.credit')
                ->get();
            $pastDebits = $pastEntries->sum('debit');
            $pastCredits = $pastEntries->sum('credit');
            if ($selectedAccount->nature == 'Deudora') {
                $summary['start_balance'] = $pastDebits - $pastCredits;
            } else {
                $summary['start_balance'] = $pastCredits - $pastDebits;
            }
            $entries = PolicyEntry::with(['policy', 'account']) 
                ->whereIn('account_id', $childAccountIds) 
                ->whereHas('policy', function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('date', [$startDate, $endDate]);
                })
                ->join('policies', 'policy_entries.policy_id', '=', 'policies.id')
                ->orderBy('policies.date')
                ->select('policy_entries.*')
                ->get();
            $runningBalance = $summary['start_balance'];
            foreach ($entries as $entry) {
                $summary['total_debit'] += $entry->debit;
                $summary['total_credit'] += $entry->credit;
                if ($selectedAccount->nature == 'Deudora') {
                    $runningBalance = $runningBalance + $entry->debit - $entry->credit;
                } else {
                    $runningBalance = $runningBalance - $entry->debit + $entry->credit;
                }
                $entry->running_balance = $runningBalance;
            }
            $summary['end_balance'] = $runningBalance;
        }
        return view('auxiliares.index', [
            'accounts' => $accounts,
            'selectedAccount' => $selectedAccount,
            'entries' => $entries,
            'summary' => $summary,
            'filters' => $request->only(['account_id', 'start_date', 'end_date']),
        ]);
    }
}