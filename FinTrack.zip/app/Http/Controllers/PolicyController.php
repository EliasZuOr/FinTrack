<?php

namespace App\Http\Controllers;

use App\Models\Policy;
use App\Models\Account; 
use App\Models\PolicyEntry;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator; 

class PolicyController extends Controller
{
    public function index(): View
    {
        $policies = Policy::with('entries')->orderBy('date', 'desc')->get();

    $accounts = Account::orderBy('code')->get();

    return view('polizas.index', [
        'policies' => $policies,
        'accounts' => $accounts
    ]);
}
    public function store(Request $request): RedirectResponse
    {
        $validatedData = $request->validate([
            'fecha' => 'required|date',
            'tipo_poliza' => 'required|string|max:255',
            'concepto' => 'required|string|max:255',
            'entries' => 'required|array|min:2',
            'entries.*.account_id' => 'required|integer|exists:accounts,id',
            'entries.*.debit' => 'nullable|numeric|min:0',
            'entries.*.credit' => 'nullable|numeric|min:0',
        ]);
        $totalDebit = 0;
        $totalCredit = 0;
        $entries = [];

        foreach ($validatedData['entries'] as $entry) {
            $debit = (float)($entry['debit'] ?? 0);
            $credit = (float)($entry['credit'] ?? 0);
            if ($debit > 0 && $credit > 0) {
                return back()->withErrors(['entries' => 'Un movimiento no puede ser cargo y abono al mismo tiempo.'])
                             ->withInput(); 
            }
            if ($debit == 0 && $credit == 0) {
                 return back()->withErrors(['entries' => 'Todos los movimientos deben tener un valor de cargo o abono.'])
                              ->withInput();
            }

            $totalDebit += $debit;
            $totalCredit += $credit;
            
            $entries[] = [
                'account_id' => $entry['account_id'],
                'debit' => $debit,
                'credit' => $credit,
            ];
        }
        if (round($totalDebit, 2) !== round($totalCredit, 2)) {
            return back()->withErrors(['entries' => 'La póliza no está cuadrada. El total de cargos (${$totalDebit}) no coincide con el total de abonos (${$totalCredit}).'])
                         ->withInput();
        }
        try {
            DB::beginTransaction();
            $policy = Policy::create([
                'date' => $validatedData['fecha'],
                'type' => $validatedData['tipo_poliza'],
                'concept' => $validatedData['concepto'],
                'total_debit' => $totalDebit,
                'total_credit' => $totalCredit,
            ]);
            foreach ($entries as $entryData) {
                $policy->entries()->create($entryData);
            }
            DB::commit();
            return redirect()->route('polizas.index')
                             ->with('success', '¡Póliza creada exitosamente!');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error_general' => 'Error al guardar la póliza: ' . $e->getMessage()])
                         ->withInput();
        }
    }
    public function destroy(Policy $policy): RedirectResponse
    {
        try {
            $policy->delete();

            return redirect()->route('polizas.index')
                             ->with('success', '¡Póliza eliminada exitosamente!');
        } catch (\Exception $e) {
            return redirect()->route('polizas.index')
                             ->with('error', 'No se pudo eliminar la póliza.');
        }
    }
    public function update(Request $request, Policy $policy): RedirectResponse
    {
        $validatedData = $request->validate([
            'fecha' => 'required|date',
            'tipo_poliza' => 'required|string|max:255',
            'concepto' => 'required|string|max:255',
            'entries' => 'required|array|min:2',
            'entries.*.account_id' => 'required|integer|exists:accounts,id',
            'entries.*.debit' => 'nullable|numeric|min:0',
            'entries.*.credit' => 'nullable|numeric|min:0',
        ]);
        $totalDebit = 0;
        $totalCredit = 0;
        $newEntriesData = [];
        foreach ($validatedData['entries'] as $entry) {
            $debit = (float)($entry['debit'] ?? 0);
            $credit = (float)($entry['credit'] ?? 0);
            if ($debit > 0 && $credit > 0) {
                return back()->withErrors(['entries' => 'Un movimiento no puede ser cargo y abono.'])->withInput();
            }
            if ($debit == 0 && $credit == 0) {
                 return back()->withErrors(['entries' => 'Movimientos deben tener cargo o abono.'])->withInput();
            }
            $totalDebit += $debit;
            $totalCredit += $credit;
            
            $newEntriesData[] = [
                'account_id' => $entry['account_id'],
                'debit' => $debit,
                'credit' => $credit,
            ];
        }

        if (round($totalDebit, 2) !== round($totalCredit, 2)) {
            return back()->withErrors(['entries' => "La póliza no está cuadrada."])->withInput();
        }
        try {
            DB::beginTransaction();
            $policy->update([
                'date' => $validatedData['fecha'],
                'type' => $validatedData['tipo_poliza'],
                'concept' => $validatedData['concepto'],
                'total_debit' => $totalDebit,
                'total_credit' => $totalCredit,
            ]);
            $policy->entries()->delete();
            $policy->entries()->createMany($newEntriesData);
            DB::commit();
            return redirect()->route('polizas.index')
                             ->with('success', '¡Póliza actualizada exitosamente!');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error_general' => 'Error al actualizar la póliza: ' . $e->getMessage()])
                         ->withInput();
        }
    }
}