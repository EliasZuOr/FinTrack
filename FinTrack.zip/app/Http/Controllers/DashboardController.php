<?php

namespace App\Http\Controllers;

use App\Models\Policy;
use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index(): View
    {
        $now = Carbon::now();
        $lastMonth = Carbon::now()->subMonth();
        $calculatePercent = function($current, $previous) {
            if ($previous == 0) {
                if ($current > 0) return (object)['value' => 100.0, 'is_new' => true];
                return (object)['value' => 0.0, 'is_new' => false];
            }
            $percent = (($current - $previous) / $previous) * 100;
            return (object)['value' => round($percent, 1), 'is_new' => false];
        };
        $ingresosMes = Policy::where('type', 'Ingreso')->whereYear('date', $now->year)->whereMonth('date', $now->month)->sum('total_credit');
        $egresosMes = Policy::where('type', 'Egreso')->whereYear('date', $now->year)->whereMonth('date', $now->month)->sum('total_debit');
        $polizasMes = Policy::whereYear('date', $now->year)->whereMonth('date', $now->month)->count();

        $ingresosMesPasado = Policy::where('type', 'Ingreso')->whereYear('date', $lastMonth->year)->whereMonth('date', $lastMonth->month)->sum('total_credit');
        $egresosMesPasado = Policy::where('type', 'Egreso')->whereYear('date', $lastMonth->year)->whereMonth('date', $lastMonth->month)->sum('total_debit');
        $polizasMesPasado = Policy::whereYear('date', $lastMonth->year)->whereMonth('date', $lastMonth->month)->count();

        $allAccounts = Account::with('policyEntries')->get();
        $totalActivosHoy = 0;
        $accountBalances = []; 
        foreach ($allAccounts as $account) {
            $totalDebit = $account->policyEntries->sum('debit');
            $totalCredit = $account->policyEntries->sum('credit');
            if ($account->nature == 'Deudora') {
                $balance = $totalDebit - $totalCredit;
                $totalActivosHoy += $balance;
            } else { 
                $balance = $totalCredit - $totalDebit;
            }
            if ($balance > 0) {
                $accountBalances[] = ['name' => $account->name, 'balance' => $balance];
            }
        }
        $lastMonthEndDate = Carbon::now()->subMonth()->endOfMonth();
        $totalActivosMesPasado = 0;
        $accountsLastMonth = Account::where('nature', 'Deudora')
            ->with(['policyEntries' => function ($query) use ($lastMonthEndDate) {
                $query->join('policies', 'policy_entries.policy_id', '=', 'policies.id')
                      ->where('policies.date', '<=', $lastMonthEndDate);
            }])
            ->get();
        foreach ($accountsLastMonth as $account) {
            $totalActivosMesPasado += $account->policyEntries->sum('debit') - $account->policyEntries->sum('credit');
        }
        $stats = [
            'saldo_total' => $totalActivosHoy,
            'ingresos_mes' => $ingresosMes,
            'egresos_mes' => $egresosMes,
            'polizas_mes' => $polizasMes,
            'saldo_percent' => $calculatePercent($totalActivosHoy, $totalActivosMesPasado),
            'ingresos_percent' => $calculatePercent($ingresosMes, $ingresosMesPasado),
            'egresos_percent' => $calculatePercent($egresosMes, $egresosMesPasado),
            'polizas_percent' => $calculatePercent($polizasMes, $polizasMesPasado),
        ];
        $labels = [];
        $ingresosData = [];
        $egresosData = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = Carbon::now()->subMonths($i);
            $labels[] = $month->shortLocaleMonth;
            $ingresosData[] = Policy::where('type', 'Ingreso')->whereYear('date', $month->year)->whereMonth('date', $month->month)->sum('total_credit');
            $egresosData[] = Policy::where('type', 'Egreso')->whereYear('date', $month->year)->whereMonth('date', $month->month)->sum('total_debit');
        }
        $ingresoEgresoData = [ 'labels' => $labels, 'ingresos' => $ingresosData, 'egresos' => $egresosData ];
        usort($accountBalances, fn($a, $b) => $b['balance'] <=> $a['balance']);
        $topAccounts = array_slice($accountBalances, 0, 4);
        $activosData = [
            'labels' => array_column($topAccounts, 'name'),
            'data' => array_column($topAccounts, 'balance'),
        ];
        $evolucionLabels = [];
        $evolucionSaldos = [];
        $deudorAccounts = Account::where('nature', 'Deudora')->with('policyEntries.policy')->get();
        for ($i = 5; $i >= 0; $i--) {
            $targetMonth = Carbon::now()->subMonths($i);
            $endDate = $targetMonth->endOfMonth(); 
            $evolucionLabels[] = $targetMonth->shortLocaleMonth;
            $totalActivosMes = 0;
            foreach ($deudorAccounts as $account) {
                $entriesInPeriod = $account->policyEntries->filter(function ($entry) use ($endDate) {
                    return $entry->policy->date <= $endDate;
                });
                $totalActivosMes += $entriesInPeriod->sum('debit') - $entriesInPeriod->sum('credit');
            }
            $evolucionSaldos[] = $totalActivosMes;
        }
        $evolucionActivosData = [
            'labels' => $evolucionLabels,
            'saldo' => $evolucionSaldos,
        ];
        return view('dashboard', [
            'stats' => $stats,
            'ingresoEgresoData' => $ingresoEgresoData,
            'evolucionActivosData' => $evolucionActivosData,
            'activosData' => $activosData,
        ]);
    }
}