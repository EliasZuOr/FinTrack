<?php

namespace App\Http\Controllers;

use App\Models\FileUpload;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse; 
use Illuminate\View\View;
use Illuminate\Support\Facades\Storage;

class ImportController extends Controller
{
    public function index(): View
    {
        $uploads = FileUpload::orderBy('created_at', 'desc')->get();
        return view('importacion.index', ['uploads' => $uploads]);
    }
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'cfdi_file' => 'required|file|mimes:xml,pdf|max:2048',
        ]);
        $file = $request->file('cfdi_file');
        $originalName = $file->getClientOriginalName();
        $fileType = $file->getClientOriginalExtension();
        $path = $file->store('cfdi_imports', 'public');
        $fileUpload = FileUpload::create([
            'file_name' => $originalName,
            'storage_path' => $path,
            'type' => strtoupper($fileType),
            'status' => 'Pendiente',
        ]);
        if ($fileType == 'xml') {
            try {
                $xmlContent = Storage::disk('public')->get($path);
                libxml_use_internal_errors(true);
                $xml = simplexml_load_string($xmlContent);
                if ($xml === false) { throw new \Exception('XML malformado.'); }
                $xml->registerXPathNamespace('cfdi', 'http://www.sat.gob.mx/cfd/4');
                $xml->registerXPathNamespace('cfdi33', 'http://www.sat.gob.mx/cfd/3');
                $comprobante = $xml->xpath('//cfdi:Comprobante');
                if (empty($comprobante)) { $comprobante = $xml->xpath('//cfdi33:Comprobante'); }
                if (!empty($comprobante)) {
                    $total = (float) $comprobante[0]['Total'];
                    $fileUpload->update([ 'status' => 'Procesado', 'amount' => $total, 'record_count' => 1 ]);
                } else {
                    throw new \Exception('No se encontró el nodo Comprobante.');
                }
            } catch (\Exception $e) {
                $fileUpload->update([ 'status' => 'Error' ]);
            }
        }
        return redirect()->route('importacion.index')->with('success', '¡Archivo subido exitosamente!');
    }
    public function destroy(FileUpload $fileUpload): RedirectResponse
    {
        try {
            Storage::disk('public')->delete($fileUpload->storage_path);
            $fileUpload->delete();
            return redirect()->route('importacion.index')
                             ->with('success', '¡Archivo eliminado exitosamente!');
        } catch (\Exception $e) {
            return redirect()->route('importacion.index')
                             ->with('error', 'No se pudo eliminar el archivo.');
        }
    }
}