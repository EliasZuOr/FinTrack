<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Account extends Model
{
    use HasFactory;

    /**
     * Los atributos que se pueden asignar masivamente.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'code',       // 'Código de Cuenta'
        'name',       // 'Nombre de la Cuenta'
        'nature',     // 'Naturaleza'
        'sat_code',   // 'Código Agrupador SAT'
        'parent_id',  // 'Cuenta Padre'
    ];
    public function policyEntries(): HasMany
    {
        return $this->hasMany(PolicyEntry::class);
    }
}