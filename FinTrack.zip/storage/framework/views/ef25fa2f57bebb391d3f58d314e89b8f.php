

<?php $__env->startSection('title', 'Gestión de Pólizas - FinTrack'); ?>

<?php $__env->startSection('content'); ?>

<div x-data="{ 
    isCreateModalOpen: false, 
    isDeleteModalOpen: false, 
    isEditModalOpen: false, 
    policyToDelete: null,
    policyToEdit: { entries: [] },
    
    entries: [], // Para el modal de CREAR
    
    init() {
        this.resetCreateEntries();
    },
    
    addCreateEntryRow() { this.entries.push({ account_id: '', debit: 0, credit: 0 }); },
    removeCreateEntryRow(index) { this.entries.splice(index, 1); },
    resetCreateEntries() {
        this.entries = [
            { account_id: '', debit: 0, credit: 0 },
            { account_id: '', debit: 0, credit: 0 }
        ];
    },
    createTotalDebit() { return this.entries.reduce((sum, entry) => sum + (parseFloat(entry.debit) || 0), 0).toFixed(2); },
    createTotalCredit() { return this.entries.reduce((sum, entry) => sum + (parseFloat(entry.credit) || 0), 0).toFixed(2); },
    isCreateBalanced() { return this.createTotalDebit() === this.createTotalCredit() && this.entries.length > 0; },

    addEditEntryRow() { this.policyToEdit.entries.push({ account_id: '', debit: 0, credit: 0 }); },
    removeEditEntryRow(index) { this.policyToEdit.entries.splice(index, 1); },
    editTotalDebit() { return this.policyToEdit.entries.reduce((sum, entry) => sum + (parseFloat(entry.debit) || 0), 0).toFixed(2); },
    editTotalCredit() { return this.policyToEdit.entries.reduce((sum, entry) => sum + (parseFloat(entry.credit) || 0), 0).toFixed(2); },
    isEditBalanced() { return this.editTotalDebit() === this.editTotalCredit() && this.policyToEdit.entries.length > 0; }
}"
@open-create-modal.window="isCreateModalOpen = true"
>

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Gestión de Pólizas</h1>
        <button @click="isCreateModalOpen = true; resetCreateEntries()" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-blue-700 transition">
            + Nueva Póliza
        </button>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative" role="alert">
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class.mb-4" role="alert">
            <div class="bg-red-500 text-white font-bold rounded-t px-4 py-2">Error al guardar</div>
            <div class="border border-t-0 border-red-400 rounded-b bg-red-100 px-4 py-3 text-red-700">
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', () => { window.dispatchEvent(new CustomEvent('open-create-modal')); });
        </script>
        <?php if(old('entries')): ?>
             <script>
                document.addEventListener('alpine:init', () => { Alpine.store('entriesData', <?php echo json_encode(old('entries')); ?>); });
                document.addEventListener('DOMContentLoaded', () => {
                    const alpineComponent = document.querySelector('[x-data]');
                    if (alpineComponent.__x) {
                        alpineComponent.__x.data.entries = Alpine.store('entriesData').map(entry => ({
                            account_id: entry.account_id || '', debit: entry.debit || 0, credit: entry.credit || 0
                        }));
                    }
                });
            </script>
        <?php endif; ?>
    <?php endif; ?>


    <div class="bg-white p-6 rounded-xl shadow-md">
        <div class="mb-4">
            <input type="text" placeholder="Buscar póliza por concepto, número..." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border border-gray-200 p-4 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center">
                <div class="flex-1 mb-4 md:mb-0">
                    <div class="flex items-center space-x-3 mb-2">
                        <span class="font-bold text-blue-600 text-lg">PL-<?php echo e($policy->id); ?></span>
                        <span class="text-xs font-medium px-2 py-0.5 rounded-full 
                            <?php echo e($policy->type == 'Diario' ? 'bg-gray-100 text-gray-600' : ''); ?>

                            <?php echo e($policy->type == 'Ingreso' ? 'bg-green-100 text-green-700' : ''); ?>

                            <?php echo e($policy->type == 'Egreso' ? 'bg-red-100 text-red-700' : ''); ?>

                        "><?php echo e($policy->type); ?></span>
                    </div>
                    <p class="text-gray-800 font-medium"><?php echo e($policy->concept); ?></p>
                    <p class="text-sm text-gray-500"><i class="mr-1">🗓️</i> <?php echo e($policy->date->format('d/m/Y')); ?></p>
                </div>
                <div class="flex items-center space-x-6">
                    <div class="text-right">
                        <span class="text-sm text-gray-500">Cargos</span>
                        <p class="font-semibold text-gray-800">$<?php echo e(number_format($policy->total_debit, 2)); ?></p>
                    </div>
                    <div class="text-right">
                        <span class="text-sm text-gray-500">Abonos</span>
                        <p class="font-semibold text-gray-800">$<?php echo e(number_format($policy->total_credit, 2)); ?></p>
                    </div>
                    <div class="flex space-x-2">
                        <button @click="policyToEdit = <?php echo e(json_encode($policy)); ?>; isEditModalOpen = true"
                                class="text-gray-500 hover:text-blue-600" title="Editar">✏️</button>
                        
                        <button @click="policyToDelete = <?php echo e($policy); ?>; isDeleteModalOpen = true" 
                                class="text-gray-500 hover:text-red-600" title="Eliminar">🗑️</button>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-4 text-center text-gray-500">No hay pólizas registradas. ¡Crea la primera!</div>
            <?php endif; ?>
        </div>
    </div>


    <div x-show="isCreateModalOpen" class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50" style="display: none;">
        <div @click.away="isCreateModalOpen = false" x-show="isCreateModalOpen" class="bg-white rounded-xl shadow-2xl w-full max-w-3xl">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-2xl font-semibold text-gray-800">Crear Nueva Póliza</h2>
            </div>
            <form action="<?php echo e(route('polizas.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="fecha" class="block text-sm font-medium text-gray-700">Fecha</label>
                            <input type="date" name="fecha" id="fecha" value="<?php echo e(old('fecha', date('Y-m-d'))); ?>" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        </div>
                        <div>
                            <label for="tipo_poliza" class="block text-sm font-medium text-gray-700">Tipo de Póliza</label>
                            <select name="tipo_poliza" id="tipo_poliza" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 <?php $__errorArgs = ['tipo_poliza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="Ingreso" <?php if(old('tipo_poliza') == 'Ingreso'): ?> selected <?php endif; ?>>Ingreso</option>
                                <option value="Egreso" <?php if(old('tipo_poliza') == 'Egreso'): ?> selected <?php endif; ?>>Egreso</option>
                                <option value="Diario" <?php if(old('tipo_poliza', 'Diario') == 'Diario'): ?> selected <?php endif; ?>>Diario</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label for="concepto" class="block text-sm font-medium text-gray-700">Concepto</label>
                        <input type="text" name="concepto" id="concepto" value="<?php echo e(old('concepto')); ?>" placeholder="Ej. Pago de nómina quincenal" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 <?php $__errorArgs = ['concepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <div>
                        <h4 class="text-md font-medium text-gray-700 mb-2">Movimientos</h4>
                        <div class="space-y-2">
                            <div class="grid grid-cols-12 gap-2 text-sm font-medium text-gray-500">
                                <div class="col-span-6">Cuenta</div>
                                <div class="col-span-2 text-right">Cargo</div>
                                <div class="col-span-2 text-right">Abono</div>
                                <div class="col-span-2"></div>
                            </div>
                            <template x-for="(entry, index) in entries" :key="index">
                                <div class="grid grid-cols-12 gap-2 items-center">
                                    <div class="col-span-6">
                                        <select :name="'entries[' + index + '][account_id]'" x-model.number="entry.account_id" class="w-full border-gray-300 rounded-lg shadow-sm text-sm focus:border-blue-500 focus:ring-blue-500">
                                            <option value="" disabled>Selecciona una cuenta...</option>
                                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($account->id); ?>"><?php echo e($account->code); ?> - <?php echo e($account->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-span-2"><input type="number" step="0.01" placeholder="$0.00" :name="'entries[' + index + '][debit]'" x-model.number="entry.debit" class="w-full border-gray-300 rounded-lg shadow-sm text-sm text-right focus:border-blue-500 focus:ring-blue-500"></div>
                                    <div class="col-span-2"><input type="number" step="0.01" placeholder="$0.00" :name="'entries[' + index + '][credit]'" x-model.number="entry.credit" class="w-full border-gray-300 rounded-lg shadow-sm text-sm text-right focus:border-blue-500 focus:ring-blue-500"></div>
                                    <div class="col-span-2 text-right"><button type="button" @click="removeCreateEntryRow(index)" class="text-red-500 hover:text-red-700" title="Eliminar movimiento">🗑️</button></div>
                                </div>
                            </template>
                            <button type="button" @click="addCreateEntryRow()" class="text-sm text-blue-600 hover:text-blue-800">+ Agregar movimiento</button>
                        </div>
                    </div>
                    <div class="flex justify-end space-x-6 pt-4 border-t">
                        <div class="text-right"><span class="text-sm font-medium text-gray-500">Total Cargos:</span><span class="text-lg font-bold text-gray-800" x-text="'$' + createTotalDebit()"></span></div>
                        <div class="text-right"><span class="text-sm font-medium text-gray-500">Total Abonos:</span><span class="text-lg font-bold text-gray-800" x-text="'$' + createTotalCredit()"></span></div>
                    </div>
                    <div x-show="!isCreateBalanced()" class="text-right text-red-500 text-sm font-medium">¡La póliza no está cuadrada!</div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Adjuntar XML / PDF</label>
                        <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                            <div class="space-y-1 text-center"><svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg><p class="text-sm text-gray-600"><span class="font-medium text-blue-600 hover:text-blue-500 cursor-pointer">Sube un archivo</span> o arrástralo aquí</p><p class="text-xs text-gray-500">CFDI (XML) o PDF</p></div>
                        </div>
                    </div>
                </div>
                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isCreateModalOpen = false" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">Cancelar</button>
                    <button type="submit" :disabled="!isCreateBalanced()" :class="isCreateBalanced() ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-300 cursor-not-allowed'" class="text-white px-4 py-2 rounded-lg font-semibold shadow transition">Guardar Póliza</button>
                </div>
            </form>
        </div>
    </div>
    <div x-show="isEditModalOpen" class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50" style="display: none;">
        <div @click.away="isEditModalOpen = false" x-show="isEditModalOpen" class="bg-white rounded-xl shadow-2xl w-full max-w-3xl">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-2xl font-semibold text-gray-800">Editar Póliza <span class="text-blue-600" x-text="policyToEdit ? 'PL-' + policyToEdit.id : ''"></span></h2>
            </div>
            <form :action="`<?php echo e(route('polizas.index')); ?>/${policyToEdit.id}`" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="edit_fecha" class="block text-sm font-medium text-gray-700">Fecha</label>
                            <input type="date" name="fecha" id="edit_fecha" x-model="policyToEdit.date" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        <div>
                            <label for="edit_tipo_poliza" class="block text-sm font-medium text-gray-700">Tipo de Póliza</label>
                            <select name="tipo_poliza" id="edit_tipo_poliza" x-model="policyToEdit.type" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="Ingreso">Ingreso</option>
                                <option value="Egreso">Egreso</option>
                                <option value="Diario">Diario</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label for="edit_concepto" class="block text-sm font-medium text-gray-700">Concepto</label>
                        <input type="text" name="concepto" id="edit_concepto" x-model="policyToEdit.concept" placeholder="Concepto de la póliza" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>
                    <div>
                        <h4 class="text-md font-medium text-gray-700 mb-2">Movimientos</h4>
                        <div class="space-y-2">
                            <div class="grid grid-cols-12 gap-2 text-sm font-medium text-gray-500">
                                <div class="col-span-6">Cuenta</div>
                                <div class="col-span-2 text-right">Cargo</div>
                                <div class="col-span-2 text-right">Abono</div>
                                <div class="col-span-2"></div>
                            </div>
                            <template x-for="(entry, index) in policyToEdit.entries" :key="index">
                                <div class="grid grid-cols-12 gap-2 items-center">
                                    <div class="col-span-6">
                                        <select :name="'entries[' + index + '][account_id]'" x-model.number="entry.account_id" class="w-full border-gray-300 rounded-lg shadow-sm text-sm focus:border-blue-500 focus:ring-blue-500">
                                            <option value="" disabled>Selecciona una cuenta...</option>
                                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($account->id); ?>"><?php echo e($account->code); ?> - <?php echo e($account->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-span-2"><input type="number" step="0.01" placeholder="$0.00" :name="'entries[' + index + '][debit]'" x-model.number="entry.debit" class="w-full border-gray-300 rounded-lg shadow-sm text-sm text-right focus:border-blue-500 focus:ring-blue-500"></div>
                                    <div class="col-span-2"><input type="number" step="0.01" placeholder="$0.00" :name="'entries[' + index + '][credit]'" x-model.number="entry.credit" class="w-full border-gray-300 rounded-lg shadow-sm text-sm text-right focus:border-blue-500 focus:ring-blue-500"></div>
                                    <div class="col-span-2 text-right"><button type="button" @click="removeEditEntryRow(index)" class="text-red-500 hover:text-red-700" title="Eliminar movimiento">🗑️</button></div>
                                </div>
                            </template>
                            <button type="button" @click="addEditEntryRow()" class="text-sm text-blue-600 hover:text-blue-800">+ Agregar movimiento</button>
                        </div>
                    </div>
                    <div class="flex justify-end space-x-6 pt-4 border-t">
                        <div class="text-right"><span class="text-sm font-medium text-gray-500">Total Cargos:</span><span class="text-lg font-bold text-gray-800" x-text="'$' + editTotalDebit()"></span></div>
                        <div class="text-right"><span class="text-sm font-medium text-gray-500">Total Abonos:</span><span class="text-lg font-bold text-gray-800" x-text="'$' + editTotalCredit()"></span></div>
                    </div>
                    <div x-show="!isEditBalanced()" class="text-right text-red-500 text-sm font-medium">¡La póliza no está cuadrada!</div>
                </div>
                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isEditModalOpen = false" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">Cancelar</button>
                    <button type="submit" :disabled="!isEditBalanced()" :class="isEditBalanced() ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-300 cursor-not-allowed'" class="text-white px-4 py-2 rounded-lg font-semibold shadow transition">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
    <div x-show="isDeleteModalOpen" class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-50" style="display: none;">
        <div @click.away="isDeleteModalOpen = false" x-show="isDeleteModalOpen" class="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <form :action="`<?php echo e(route('polizas.index')); ?>/${policyToDelete ? policyToDelete.id : ''}`" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="p-6 border-b border-gray-200"><h2 class="text-2xl font-semibold text-gray-800">Confirmar Eliminación</h2></div>
                <div class="p-6">
                    <p class="text-gray-600">¿Estás seguro de que deseas eliminar la póliza?</p>
                    <div class="mt-2 bg-gray-100 p-3 rounded-lg">
                        <span class="font-bold text-gray-800" x-text="policyToDelete ? 'PL-' + policyToDelete.id : ''"></span>
                        <p class="text-sm text-gray-700" x-text="policyToDelete ? policyToDelete.concept : ''"></p>
                    </div>
                    <p class="text-sm text-red-600 mt-4">Esta acción no se puede deshacer.</p>
                </div>
                <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-2">
                    <button type="button" @click="isDeleteModalOpen = false; policyToDelete = null" class="bg-white text-gray-700 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 shadow-sm">Cancelar</button>
                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold shadow hover:bg-red-700">Eliminar Póliza</button>
                </div>
            </form>
        </div>
    </div>
    </div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Modular\FinTrack\resources\views/polizas/index.blade.php ENDPATH**/ ?>