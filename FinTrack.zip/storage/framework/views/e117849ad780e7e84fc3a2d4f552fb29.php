

<?php $__env->startSection('title', 'Dashboard - FinTrack'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Dashboard</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Total Activos (Saldo)</h5>
            <p class="text-3xl font-bold text-gray-800">$<?php echo e(number_format($stats['saldo_total'], 2)); ?></p>

            <?php if($stats['saldo_percent']->is_new): ?>
                <span class="text-xs font-medium bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Nuevo</span>
            <?php elseif($stats['saldo_percent']->value != 0): ?>
                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'text-xs',
                    'text-green-500' => $stats['saldo_percent']->value > 0,
                    'text-red-500' => $stats['saldo_percent']->value < 0,
                ]); ?>">
                    <?php echo e($stats['saldo_percent']->value > 0 ? '+' : ''); ?><?php echo e($stats['saldo_percent']->value); ?>% vs mes anterior
                </p>
            <?php endif; ?>
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Ingresos (Mes)</h5>
            <p class="text-3xl font-bold text-green-600">$<?php echo e(number_format($stats['ingresos_mes'], 2)); ?></p>
            
            <?php if($stats['ingresos_percent']->is_new): ?>
                <span class="text-xs font-medium bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Nuevo</span>
            <?php elseif($stats['ingresos_percent']->value != 0): ?>
                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'text-xs',
                    'text-green-500' => $stats['ingresos_percent']->value > 0,
                    'text-red-500' => $stats['ingresos_percent']->value < 0,
                ]); ?>">
                    <?php echo e($stats['ingresos_percent']->value > 0 ? '+' : ''); ?><?php echo e($stats['ingresos_percent']->value); ?>% vs mes anterior
                </p>
            <?php endif; ?>
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Egresos (Mes)</h5>
            <p class="text-3xl font-bold text-red-600">$<?php echo e(number_format($stats['egresos_mes'], 2)); ?></p>
            
            <?php if($stats['egresos_percent']->is_new): ?>
                <span class="text-xs font-medium bg-red-100 text-red-700 px-2 py-0.5 rounded-full">Nuevo</span>
            <?php elseif($stats['egresos_percent']->value != 0): ?>
                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'text-xs',
                    'text-red-500' => $stats['egresos_percent']->value > 0,
                    'text-green-500' => $stats['egresos_percent']->value < 0,
                ]); ?>">
                    <?php echo e($stats['egresos_percent']->value > 0 ? '+' : ''); ?><?php echo e($stats['egresos_percent']->value); ?>% vs mes anterior
                </p>
            <?php endif; ?>
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-sm font-medium text-gray-500">Pólizas (Mes)</h5>
            <p class="text-3xl font-bold text-gray-800"><?php echo e($stats['polizas_mes']); ?></p>
            
            <?php if($stats['polizas_percent']->is_new): ?>
                <span class="text-xs font-medium bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Nuevo</span>
            <?php elseif($stats['polizas_percent']->value != 0): ?>
                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'text-xs',
                    'text-green-500' => $stats['polizas_percent']->value > 0,
                    'text-red-500' => $stats['polizas_percent']->value < 0,
                ]); ?>">
                    <?php echo e($stats['polizas_percent']->value > 0 ? '+' : ''); ?><?php echo e($stats['polizas_percent']->value); ?>% vs mes anterior
                </p>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Ingreso vs Egreso (Últimos 6 meses)</h5>
            <canvas id="ingresoEgresoChart"></canvas>
        </div>
        <div class="lg:col-span-1 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Evolución de Activos (Últimos 6 meses)</h5>
            <canvas id="evolucionSaldoChart"></canvas>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-1 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Distribución de Activos (Top 4)</h5>
            <canvas id="activosChart" class="max-h-64 mx-auto"></canvas>
        </div>
        <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <h5 class="text-lg font-semibold mb-4">Accesos Rápidos</h5>
            <div class="grid grid-cols-2 gap-4">
                <a href="<?php echo e(route('polizas.index')); ?>" class="flex items-center p-4 bg-blue-100 text-blue-700 rounded-lg font-medium hover:bg-blue-200">
                    <i class="mr-3 text-xl">📝</i> Nueva Póliza
                </a>
                <a href="<?php echo e(route('cuentas.index')); ?>" class="flex items-center p-4 bg-green-100 text-green-700 rounded-lg font-medium hover:bg-green-200">
                    <i class="mr-3 text-xl">📚</i> Catálogo
                </a>
                <a href="<?php echo e(route('auxiliares.index')); ?>" class="flex items-center p-4 bg-purple-100 text-purple-700 rounded-lg font-medium hover:bg-purple-200">
                    <i class="mr-3 text-xl">📉</i> Ver Auxiliares
                </a>
                <a href="<?php echo e(route('importacion.index')); ?>" class="flex items-center p-4 bg-yellow-100 text-yellow-700 rounded-lg font-medium hover:bg-yellow-200">
                    <i class="mr-3 text-xl">📤</i> Importar CFDI
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const ctxIngresoEgreso = document.getElementById('ingresoEgresoChart').getContext('2d');
            new Chart(ctxIngresoEgreso, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($ingresoEgresoData['labels'], 15, 512) ?>,
                    datasets: [
                        {
                            label: 'Ingresos',
                            data: <?php echo json_encode($ingresoEgresoData['ingresos'], 15, 512) ?>,
                            backgroundColor: 'rgba(34, 197, 94, 0.7)', 
                            borderRadius: 4,
                        },
                        {
                            label: 'Egresos',
                            data: <?php echo json_encode($ingresoEgresoData['egresos'], 15, 512) ?>,
                            backgroundColor: 'rgba(239, 68, 68, 0.7)', 
                            borderRadius: 4,
                        }
                    ]
                },
                options: { 
                    responsive: true, 
                    scales: { y: { beginAtZero: true } },
                    plugins: { legend: { position: 'top' } }
                }
            });
            const ctxEvolucionSaldo = document.getElementById('evolucionSaldoChart').getContext('2d');
            new Chart(ctxEvolucionSaldo, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($evolucionActivosData['labels'], 15, 512) ?>,
                    datasets: [{
                        label: 'Total Activos', 
                        data: <?php echo json_encode($evolucionActivosData['saldo'], 15, 512) ?>,
                        borderColor: 'rgba(59, 130, 246, 1)', 
                        fill: false,
                        tension: 0.1
                    }]
                },
                options: { 
                    responsive: true, 
                    scales: { y: { beginAtZero: true } },
                    plugins: { legend: { position: 'top' } }
                }
            });

            const ctxActivos = document.getElementById('activosChart').getContext('2d');
            new Chart(ctxActivos, {
                type: 'doughnut',
                data: {
                    labels: <?php echo json_encode($activosData['labels'], 15, 512) ?>,
                    datasets: [{
                        data: <?php echo json_encode($activosData['data'], 15, 512) ?>,
                        backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6']
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Modular\FinTrack\resources\views/dashboard.blade.php ENDPATH**/ ?>