

<?php $__env->startSection('title', 'Movimientos Auxiliares - FinTrack'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Movimientos Auxiliares</h1>

    <div class="bg-white p-6 rounded-xl shadow-md mb-8">
        <form action="<?php echo e(route('auxiliares.index')); ?>" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            
            <div class="col-span-1 md:col-span-2">
                <label for="account_id" class="block text-sm font-medium text-gray-700">Cuenta a Consultar</label>
                <select name="account_id" id="account_id" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    <option value="">Selecciona una cuenta...</option>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($account->id); ?>" <?php if(isset($filters['account_id']) && $filters['account_id'] == $account->id): ?> selected <?php endif; ?>>
                            <?php echo e($account->code); ?> - <?php echo e($account->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div>
                <label for="start_date" class="block text-sm font-medium text-gray-700">Fecha Inicio</label>
                <input type="date" name="start_date" id="start_date" 
                       value="<?php echo e($filters['start_date'] ?? \Carbon\Carbon::now()->startOfYear()->toDateString()); ?>" 
                       class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
            </div>
            
            <div>
                <label for="end_date" class="block text-sm font-medium text-gray-700">Fecha Fin</label>
                <input type="date" name="end_date" id="end_date" 
                       value="<?php echo e($filters['end_date'] ?? \Carbon\Carbon::now()->toDateString()); ?>" 
                       class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
            </div>
            
            <div class="col-span-1 md:col-span-4 flex justify-end">
                <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold shadow hover:bg-blue-700 transition">
                    Consultar
                </button>
            </div>
        </form>
    </div>

    <?php if($selectedAccount): ?>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Saldo Inicial</h5>
                <p class="text-2xl font-bold text-gray-800">$<?php echo e(number_format($summary['start_balance'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Total Cargos (Debe)</h5>
                <p class="text-2xl font-bold text-green-600">$<?php echo e(number_format($summary['total_debit'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Total Abonos (Haber)</h5>
                <p class="text-2xl font-bold text-red-600">$<?php echo e(number_format($summary['total_credit'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-xl shadow-md">
                <h5 class="text-sm font-medium text-gray-500">Saldo Final</h5>
                <p class="text-2xl font-bold text-gray-800">$<?php echo e(number_format($summary['end_balance'], 2)); ?></p>
            </div>
        </div>

        <div class="bg-white p-6 rounded-xl shadow-md">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">
                Desglose de: <?php echo e($selectedAccount->code); ?> - <?php echo e($selectedAccount->name); ?> (y sub-cuentas)
            </h3>
            <div class="border border-gray-200 rounded-lg overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Póliza</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Concepto</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cuenta</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Cargo</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Abono</th>
                            <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Saldo</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <tr class="bg-gray-50">
                            <td class="px-4 py-3 text-sm font-medium text-gray-900" colspan="6">Saldo Inicial al <?php echo e(\Carbon\Carbon::parse($filters['start_date'] ?? '')->format('d/m/Y')); ?></td>
                            <td class="px-4 py-3 text-right text-sm font-medium text-gray-900">$<?php echo e(number_format($summary['start_balance'], 2)); ?></td>
                        </tr>
                        
                        <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($entry->policy->date->format('d/m/Y')); ?></td>
                                <td class="px-4 py-3 text-sm text-blue-600">PL-<?php echo e($entry->policy->id); ?></td>
                                <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($entry->policy->concept); ?></td>
                                <td class="px-4 py-3 text-sm text-gray-700">
                                    <?php echo e($entry->account->code); ?> - <?php echo e($entry->account->name); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-right text-green-600">
                                    <?php echo e($entry->debit > 0 ? '$'.number_format($entry->debit, 2) : '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-right text-red-600">
                                    <?php echo e($entry->credit > 0 ? '$'.number_format($entry->credit, 2) : '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-right font-medium text-gray-900">
                                    $<?php echo e(number_format($entry->running_balance, 2)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="p-4 text-center text-gray-500">
                                    No se encontraron movimientos para esta ramificación de cuentas en el periodo.
                                </td>
                            </tr>
                        <?php endif; ?>

                        <tr class="bg-gray-50">
                            <td class="px-4 py-3 text-sm font-medium text-gray-900" colspan="6">Saldo Final al <?php echo e(\Carbon\Carbon::parse($filters['end_date'] ?? '')->format('d/m/Y')); ?></td>
                            <td class="px-4 py-3 text-right text-sm font-bold text-gray-900">$<?php echo e(number_format($summary['end_balance'], 2)); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <?php else: ?>
        <div class="bg-white p-6 rounded-xl shadow-md text-center text-gray-500">
            <p>Por favor, selecciona una cuenta y un rango de fechas para ver sus movimientos auxiliares.</p>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Modular\FinTrack\resources\views/auxiliares/index.blade.php ENDPATH**/ ?>