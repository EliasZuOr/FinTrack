<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'FinTrack'); ?></title>

    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-blue-50/50 antialiased">

    <div class="flex min-h-screen">

        <nav class="w-64 bg-white shadow-lg p-4 flex flex-col">
            <div class="text-2xl font-bold text-blue-600 mb-8">FinTrack</div>
            <ul class="space-y-2">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" 
                       class="flex items-center p-2 rounded-lg <?php echo e(request()->routeIs('dashboard') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'); ?>">
                       <i class="mr-3">📊</i> Dashboard
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('polizas.index')); ?>" 
                    class="flex items-center p-2 rounded-lg <?php echo e(request()->routeIs('polizas.*') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'); ?>">
                    <i class="mr-3">🧾</i> Pólizas
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('cuentas.index')); ?>" 
                    class="flex items-center p-2 rounded-lg <?php echo e(request()->routeIs('cuentas.*') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'); ?>">
                    <i class="mr-3">📚</i> Catálogo de Cuentas
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('auxiliares.index')); ?>" 
                    class="flex items-center p-2 rounded-lg <?php echo e(request()->routeIs('auxiliares.index') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'); ?>">
                    <i class="mr-3">📉</i> Auxiliares
                    </a>
                </li>
                <li>
            <a href="<?php echo e(route('importacion.index')); ?>" 
            class="flex items-center p-2 rounded-lg <?php echo e(request()->routeIs('importacion.index') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-gray-100'); ?>">
            <i class="mr-3">📤</i> Importación
            </a>
        </li>
        </ul>
            <div class="mt-auto text-center text-gray-500 text-sm">
                FinTrack © 2025
            </div>
        </nav>

        <main class="flex-1 p-8">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <script>
    window.watsonAssistantChatOptions = {
        integrationID: "90218aee-ee27-4311-b0ce-f61b3301565c",
        region: "au-syd",
        serviceInstanceID: "2014135a-ab29-487b-83ba-dfb6211412cb",
        launcherText: '🤖', 

        onLoad: async (instance) => { 
        await instance.render();
        instance.updateLauncher({ text: '🤖' });
        }
    };
    setTimeout(function(){
        const t=document.createElement('script');
        t.src="https://web-chat.global.assistant.watson.appdomain.cloud/versions/" + (window.watsonAssistantChatOptions.clientVersion || 'latest') + "/WatsonAssistantChatEntry.js";
        document.head.appendChild(t);
    });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Modular\FinTrack\resources\views/layouts/app.blade.php ENDPATH**/ ?>