<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('file_uploads', function (Blueprint $table) {
        $table->id();
        $table->string('file_name'); // El nombre original del archivo
        $table->string('storage_path'); // Dónde se guardó en el servidor
        $table->string('type'); // "XML", "PDF", etc.
        $table->string('status')->default('Pendiente'); // "Pendiente", "Procesado", "Error"
        $table->integer('record_count')->nullable(); // Cuántos registros (ej. 1)
        $table->decimal('amount', 15, 2)->nullable(); // Monto del CFDI
        $table->timestamps(); // Para la columna "Fecha"
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('file_uploads');
    }
};
