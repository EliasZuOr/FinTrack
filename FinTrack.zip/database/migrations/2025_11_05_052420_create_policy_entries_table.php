<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('policy_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('policy_id')->constrained('policies')->onDelete('cascade');
            $table->foreignId('account_id')->constrained('accounts')->onDelete('restrict'); // Vincula a una cuenta del catálogo
            
            $table->decimal('debit', 15, 2)->default(0); // 'Cargo' 
            $table->decimal('credit', 15, 2)->default(0); // 'Abono' 
            
            $table->string('description')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('policy_entries');
    }
};