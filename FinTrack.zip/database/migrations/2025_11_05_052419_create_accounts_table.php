<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique(); // 'Código de Cuenta' 
            $table->string('name'); // 'Nombre de la Cuenta' 
            $table->string('nature'); // 'Naturaleza' (Deudora/Acreedora) 
            $table->string('sat_code')->nullable(); // 'Código Agrupador SAT' 
            
            // Para la estructura de árbol ('Cuenta Padre') 
            $table->foreignId('parent_id')->nullable()->constrained('accounts')->onDelete('set null');
            
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('accounts');
    }
};